# PassVault Android

Android-версия PassVault. Проект собирается в APK.

Важно: это подготовленный Android-проект; для реального хранения паролей перед публикацией следует заменить простое локальное хранение на Android Keystore + зашифрованную БД.

Сборка:
- открыть проект в Android Studio;
- дождаться Gradle Sync;
- Build -> Build APK(s).
