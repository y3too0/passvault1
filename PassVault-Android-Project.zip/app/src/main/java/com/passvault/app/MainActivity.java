package com.passvault.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, list; EditText search; ArrayList<Account> accounts=new ArrayList<>();
    int purple=Color.rgb(124,92,255);
    public void onCreate(Bundle b){super.onCreate(b); load(); build(); render();}
    TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(sp);t.setPadding(16,12,16,12);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundColor(Color.rgb(25,29,39));return b;}
    void build(){
      root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(18,18,18,12);root.setBackgroundColor(Color.rgb(9,11,16));
      LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
      TextView title=tv("PassVault\nВаше защищённое хранилище",22);title.setTypeface(null,1);head.addView(title,new LinearLayout.LayoutParams(0,-2,1));
      Button add=btn("＋"); add.setOnClickListener(v->dialog(null));head.addView(add,new LinearLayout.LayoutParams(60,55));root.addView(head);
      search=new EditText(this);search.setHint("Поиск аккаунтов…");search.setHintTextColor(Color.GRAY);search.setTextColor(Color.WHITE);root.addView(search,new LinearLayout.LayoutParams(-1,60));search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){render();}public void afterTextChanged(android.text.Editable e){}});
      LinearLayout stats=new LinearLayout(this); TextView st=tv("  "+accounts.size()+" аккаунтов     ★ "+fav()+" избранных",13);stats.addView(st);root.addView(stats);
      ScrollView sc=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
      LinearLayout nav=new LinearLayout(this);String[] ns={"Все","Избранное","Настройки"};for(String n:ns){Button x=btn(n);nav.addView(x,new LinearLayout.LayoutParams(0,58,1));if(n.equals("Все"))x.setOnClickListener(v->render());if(n.equals("Настройки"))x.setOnClickListener(v->settings());}root.addView(nav);
      setContentView(root);
    }
    int fav(){int n=0;for(Account a:accounts)if(a.fav)n++;return n;}
    void render(){if(list==null)return;list.removeAllViews();String q=search==null?"":search.getText().toString().toLowerCase();for(Account a:accounts)if((a.service+" "+a.login+" "+a.email).toLowerCase().contains(q)){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(6,8,6,8);TextView info=tv((a.icon.length()>0?a.icon:"●")+"  "+a.service+"\n      "+a.login,15);row.addView(info,new LinearLayout.LayoutParams(0,72,1));Button cp=btn("Копировать");cp.setOnClickListener(v->copy(a.password));row.addView(cp,new LinearLayout.LayoutParams(105,58));Button op=btn("Открыть");op.setOnClickListener(v->dialog(a));row.addView(op,new LinearLayout.LayoutParams(90,58));list.addView(row);}}
    void copy(String s){((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("PassVault",s));Toast.makeText(this,"Скопировано",Toast.LENGTH_SHORT).show();}
    void dialog(Account old){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(30,5,30,5);EditText service=e("Сервис",old==null?"":old.service),login=e("Логин",old==null?"":old.login),email=e("Почта",old==null?"":old.email),pass=e("Пароль",old==null?"":old.password);pass.setInputType(129);l.addView(service);l.addView(login);l.addView(email);l.addView(pass);new AlertDialog.Builder(this).setTitle(old==null?"Новый аккаунт":"Редактировать").setView(l).setPositiveButton("Сохранить",(d,w)->{Account a=old==null?new Account():old;a.service=service.getText().toString();a.login=login.getText().toString();a.email=email.getText().toString();a.password=pass.getText().toString();if(old==null)accounts.add(a);save();render();}).setNegativeButton("Отмена",null).show();}
    EditText e(String hint,String val){EditText e=new EditText(this);e.setHint(hint);e.setText(val);e.setTextColor(Color.WHITE);e.setHintTextColor(Color.GRAY);return e;}
    void settings(){new AlertDialog.Builder(this).setTitle("Настройки").setItems(new String[]{"Изменить PIN","Удалить все данные"},(d,w)->{if(w==1&&confirm("Удалить все аккаунты?")){accounts.clear();save();render();}}).show();}
    boolean confirm(String s){new AlertDialog.Builder(this).setMessage(s).setPositiveButton("Удалить",(d,w)->{accounts.clear();save();render();}).setNegativeButton("Отмена",null).show();return false;}
    void save(){getPreferences(0).edit().putString("data",new com.google.gson.Gson().toJson(accounts)).apply();}
    void load(){try{String s=getPreferences(0).getString("data","[]");Account[] a=new com.google.gson.Gson().fromJson(s,Account[].class);accounts.addAll(Arrays.asList(a));}catch(Exception e){}}
    static class Account{String service="",login="",email="",password="",icon="";boolean fav=false;}
}